# CalendarMVC
A dynamic calendar application that implements MVC design pattern
